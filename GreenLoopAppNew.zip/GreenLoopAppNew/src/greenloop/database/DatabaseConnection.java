package greenloop.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Helper class just for establishing the MySQL connection
public class DatabaseConnection {
    // My local database credentials - need to make sure MySQL is running before launching!
    private static final String URL = "jdbc:mysql://localhost:3306/greenloop_db";
    private static final String USER = "root"; 
    private static final String PASSWORD = "Apple@5#"; 

    // Returns a connection object that other classes can use to run queries
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}