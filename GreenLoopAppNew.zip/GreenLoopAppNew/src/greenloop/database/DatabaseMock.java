package greenloop.database;

import greenloop.models.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// This class currently acts as a giant DAO handling everything. 
// (We should probably split this into separate DAOs later for better OOP).
public class DatabaseMock {
    // Database configuration credentials
    private static final String URL = "jdbc:mysql://localhost:3306/greenloop_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Apple@5#"; 

    // Method to grab the connection
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            System.err.println("❌ Database connection failed!");
            e.printStackTrace();
        }
        return connection;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PRODUCTS - executing CRUD operations for products table
    // ═══════════════════════════════════════════════════════════════════
    public static List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM products")) {
            // Loop through result set and create Product objects
            while(rs.next()) list.add(new Product(rs.getString("product_id"), rs.getString("name"), rs.getDouble("price"), rs.getString("eco_rating"), rs.getInt("stock_qty"), rs.getInt("reorder_level")));
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }

    // Using REPLACE INTO so it inserts a new product or updates an existing one with the same ID
    public static void saveProduct(Product p) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("REPLACE INTO products (product_id, name, price, eco_rating, stock_qty, reorder_level) VALUES (?,?,?,?,?,?)")) {
            ps.setString(1, p.getId()); ps.setString(2, p.getName()); ps.setDouble(3, p.getPrice()); ps.setString(4, p.getEcoRating()); ps.setInt(5, p.getStockQty()); ps.setInt(6, p.getReorderLevel());
            ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // Deletes product by its primary key
    public static void deleteProduct(String id) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM products WHERE product_id=?")) {
            ps.setString(1, id); ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // Quick method to just update the stock quantity when new shipments arrive
    public static void updateProductStock(String id, int addedQty) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE products SET stock_qty = stock_qty + ? WHERE product_id=?")) {
            ps.setInt(1, addedQty); ps.setString(2, id); ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // Reduces stock when an order is placed
    public static void decreaseProductStock(String id, int qty) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE products SET stock_qty = stock_qty - ? WHERE product_id=?")) {
            ps.setInt(1, qty); ps.setString(2, id); ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // Helper to find a product just by its name (useful for combo boxes in UI)
    public static Product getProductByName(String name) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("SELECT * FROM products WHERE name=?")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()) return new Product(rs.getString("product_id"), rs.getString("name"), rs.getDouble("price"), rs.getString("eco_rating"), rs.getInt("stock_qty"), rs.getInt("reorder_level"));
            }
        } catch(Exception e) { e.printStackTrace(); }
        return null;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  CLIENTS - managing client data
    // ═══════════════════════════════════════════════════════════════════
    public static List<Client> getAllClients() {
        List<Client> list = new ArrayList<>();
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM clients")) {
            while(rs.next()) list.add(new Client(rs.getString("client_id"), rs.getString("name"), rs.getString("contact"), rs.getString("email")));
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }

    public static void saveClient(Client cl) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("REPLACE INTO clients (client_id, name, contact, email) VALUES (?,?,?,?)")) {
            ps.setString(1, cl.getId()); ps.setString(2, cl.getName()); ps.setString(3, cl.getContact()); ps.setString(4, cl.getEmail());
            ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    public static void deleteClient(String id) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM clients WHERE client_id=?")) {
            ps.setString(1, id); ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  AGENTS - courier assignment data
    // ═══════════════════════════════════════════════════════════════════
    public static List<DeliveryAgent> getAllAgents() {
        List<DeliveryAgent> list = new ArrayList<>();
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM delivery_agents")) {
            while(rs.next()) list.add(new DeliveryAgent(rs.getString("agent_id"), rs.getString("name"), rs.getString("vehicle_details"), rs.getString("email")));
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }

    public static void saveAgent(DeliveryAgent a) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("REPLACE INTO delivery_agents (agent_id, name, vehicle_details, email) VALUES (?,?,?,?)")) {
            ps.setString(1, a.getAgentId()); ps.setString(2, a.getName()); ps.setString(3, a.getVehicleDetails()); ps.setString(4, a.getEmail());
            ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    public static void deleteAgent(String id) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM delivery_agents WHERE agent_id=?")) {
            ps.setString(1, id); ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ORDERS - tracking dispatch logistics
    // ═══════════════════════════════════════════════════════════════════
    public static List<Order> getAllOrders() {
        List<Order> list = new ArrayList<>();
        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM orders")) {
            while(rs.next()) list.add(new Order(rs.getString("order_id"), rs.getString("client_name"), rs.getString("product_name"), rs.getInt("quantity"), rs.getDouble("total_amount"), rs.getString("status"), rs.getString("delivery_agent_name")));
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }

    public static void saveOrder(Order o) {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement("REPLACE INTO orders (order_id, client_name, product_name, quantity, total_amount, status, delivery_agent_name) VALUES (?,?,?,?,?,?,?)")) {
            ps.setString(1, o.getOrderId()); ps.setString(2, o.getClientName()); ps.setString(3, o.getProductName()); ps.setInt(4, o.getQuantity()); ps.setDouble(5, o.getTotalAmount()); ps.setString(6, o.getStatus()); ps.setString(7, o.getDeliveryAgentName());
            ps.executeUpdate();
        } catch(Exception e) { e.printStackTrace(); }
    }
}