package greenloop.ui;

import greenloop.dao.*;
import greenloop.models.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Dashboard extends JFrame {

    // Instantiating standard clean DAO layers to handle baseline database operations
    private final ProductDAO pDAO       = new ProductDAO();
    private final ClientDAO cDAO        = new ClientDAO();
    private final DeliveryAgentDAO aDAO = new DeliveryAgentDAO();
    private final OrderDAO oDAO         = new OrderDAO();

    // ═══════════════════════════════════════════════════════════════════
    //  PREMIUM COLOR SYSTEM
    // ═══════════════════════════════════════════════════════════════════
    public static final Color C_BG          = new Color(7,   13,  10);
    public static final Color C_BG2         = new Color(11,  19,  15);
    public static final Color C_SIDEBAR     = new Color(9,   16,  12);
    public static final Color C_CARD        = new Color(15,  25,  19);
    public static final Color C_ACCENT      = new Color(68,  218, 116); 
    public static final Color C_ACCENT_DIM  = new Color(40,  140,  72);
    public static final Color C_GOLD        = new Color(255, 200,  65);
    public static final Color C_GOLD_DIM    = new Color(160, 120,  20);
    public static final Color C_SAPPHIRE    = new Color(65,  155, 240);
    public static final Color C_TEXT        = new Color(228, 243, 233);
    public static final Color C_TEXT_MID    = new Color(155, 195, 170);
    public static final Color C_TEXT_MUTED  = new Color(90,  128, 105);
    public static final Color C_BORDER      = new Color(28,  50,  38);
    public static final Color C_DANGER      = new Color(255,  80,  80); 
    public static final Color C_DANGER_DIM  = new Color(140,  25,  25);
    public static final Color C_GLASS_SHEEN = new Color(255, 255, 255, 9);
    public static final Color C_ROW_ALT     = new Color(12,  20,  16);
    public static final Color C_ROW_EVEN    = new Color(16,  27,  21);

    // ═══════════════════════════════════════════════════════════════════
    //  FONT SYSTEM
    // ═══════════════════════════════════════════════════════════════════
    private static final Font F_BRAND  = new Font("Segoe UI", Font.BOLD,   22);
    private static final Font F_BRAND2 = new Font("Segoe UI", Font.PLAIN,  10);
    private static final Font F_NAV    = new Font("Segoe UI", Font.BOLD,   13);
    private static final Font F_NAV_S  = new Font("Segoe UI", Font.PLAIN,  10);
    private static final Font F_TITLE  = new Font("Segoe UI", Font.BOLD,   16);
    private static final Font F_TITLE2 = new Font("Segoe UI", Font.BOLD,   13);
    private static final Font F_LABEL  = new Font("Segoe UI", Font.BOLD,   12);
    private static final Font F_INPUT  = new Font("Segoe UI", Font.PLAIN,  13);
    private static final Font F_SMALL  = new Font("Segoe UI", Font.PLAIN,  11);
    private static final Font F_TINY   = new Font("Segoe UI", Font.BOLD,   10);
    private static final Font F_STAT   = new Font("Segoe UI", Font.BOLD,   30);
    private static final Font F_MONO   = new Font("Consolas",  Font.PLAIN,  12);
    private static final Font F_CLOCK  = new Font("Consolas",  Font.BOLD,   12);

    private JPanel       contentArea;
    private CardLayout   cardLayout; 
    private NavButton[]  navButtons;
    private JLabel       statusLabel;

    private JTable            productTable, clientTable, agentTable, orderTable;
    private DefaultTableModel productModel, clientModel, agentModel, orderModel;

    private JTextField txtProdId, txtProdName, txtProdPrice, txtProdEco, txtProdQty, txtProdReorder;
    private JTextField txtClientId, txtClientName, txtClientContact, txtClientEmail;
    private JTextField txtAgentId, txtAgentName, txtAgentVehicle, txtAgentEmail;
    private JTextField txtOrderId, txtOrderQty;
    
    private JComboBox<String> comboClients, comboProducts, comboAgents;
    private JLabel         lblTotalCalc;

    private final JLabel[] statLabels = new JLabel[4];
    private static final int PARTICLE_COUNT = 45;
    private final List<Particle> particles = new ArrayList<>();

    private static class Particle {
        float x, y, size, speed, alpha, wobble, wobbleSpeed;
        int kind;
        void reset(int w, int h, boolean init) {
            x = (float)(Math.random() * w);
            y = init ? (float)(Math.random() * h) : h + 12f;
            size  = (float)(Math.random() * 3.5 + 0.8);
            speed = (float)(Math.random() * 0.55 + 0.18);
            alpha = (float)(Math.random() * 0.22 + 0.04);
            wobble      = (float)(Math.random() * Math.PI * 2);
            wobbleSpeed = (float)(Math.random() * 0.022 + 0.008);
            kind  = (int)(Math.random() * 3);
        }
    }

    public Dashboard() {
        setTitle("GreenLoop — Eco-Packaging Operations Centre");
        setSize(1300, 820);
        setMinimumSize(new Dimension(1100, 700));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        for (int i = 0; i < PARTICLE_COUNT; i++) {
            Particle p = new Particle();
            p.reset(1300, 820, true);
            particles.add(p);
        }

        JPanel root = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, C_BG, getWidth(), getHeight(), C_BG2));
                g2.fillRect(0, 0, getWidth(), getHeight());
                RadialGradientPaint vignette = new RadialGradientPaint(
                    getWidth() / 2f, getHeight() / 2f,
                    Math.max(getWidth(), getHeight()) * 0.7f,
                    new float[]{0f, 1f},
                    new Color[]{new Color(0,0,0,0), new Color(0,0,0,80)}
                );
                g2.setPaint(vignette);
                g2.fillRect(0, 0, getWidth(), getHeight());
                renderParticles(g2);
                g2.dispose();
            }
        };
        root.setOpaque(false);
        add(root);

        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(buildMain(),    BorderLayout.CENTER);

        new Timer(33, e -> {
            int w = root.getWidth(), h = root.getHeight();
            for (Particle p : particles) {
                p.y -= p.speed;
                p.wobble += p.wobbleSpeed;
                p.x += (float) Math.sin(p.wobble) * 0.35f;
                if (p.y < -20) p.reset(w, h, false);
            }
            root.repaint();
        }).start();

        showCard("dashboard");
        checkAlerts();
    }

    private void renderParticles(Graphics2D g2) {
        for (Particle p : particles) {
            Composite prev = g2.getComposite();
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, p.alpha));
            g2.setColor(C_ACCENT);
            int px = (int) p.x, py = (int) p.y, ps = Math.max(1, (int) p.size);
            switch (p.kind) {
                case 0: g2.fillOval(px, py, ps, ps); break;
                case 1: g2.setStroke(new BasicStroke(0.6f)); g2.drawOval(px, py, ps * 2, ps * 2); break;
                case 2: int[] dx = {px, px+ps, px, px-ps}; int[] dy = {py-ps, py, py+ps, py}; g2.fillPolygon(dx, dy, 4); break;
            }
            g2.setComposite(prev);
        }
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, C_SIDEBAR, 0, getHeight(), new Color(5, 10, 8)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setPaint(new GradientPaint(getWidth()-1, 0, new Color(68,218,116,60), getWidth(), 0, new Color(68,218,116, 0)));
                g2.fillRect(getWidth()-1, 0, 1, getHeight());
                g2.dispose();
            }
        };
        sidebar.setPreferredSize(new Dimension(248, 0));
        sidebar.setOpaque(false);

        JPanel brand = new JPanel(new BorderLayout(14, 0)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(C_BORDER);
                g2.fillRect(18, getHeight()-1, getWidth()-36, 1);
                g2.dispose();
            }
        };
        brand.setOpaque(false);
        brand.setBorder(new EmptyBorder(24, 18, 22, 18));

        JPanel logoPanel = new JPanel() {
            int pulse = 0;
            { new Timer(45, e -> { pulse = (pulse + 4) % 360; repaint(); }).start(); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth()/2, cy = getHeight()/2, r = 22;
                float pf = (float)(0.5 + 0.5 * Math.sin(Math.toRadians(pulse)));
                for (int i = 5; i >= 1; i--) {
                    int alpha = (int)(pf * i * 14);
                    g2.setColor(new Color(68, 218, 116, alpha));
                    g2.fillOval(cx-r-i*2, cy-r-i*2, (r+i*2)*2, (r+i*2)*2);
                }
                g2.setPaint(new GradientPaint(cx-r, cy-r, new Color(55,185,95), cx+r, cy+r, new Color(22,115,55)));
                g2.fillOval(cx-r, cy-r, r*2, r*2);
                g2.setColor(new Color(255,255,255,35));
                g2.fillArc(cx-r+2, cy-r+2, r*2-4, (r-2)*2-4, 25, 140);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 15)); g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("GL", cx - fm.stringWidth("GL")/2, cy + fm.getAscent()/2 - 2);
                g2.dispose();
            }
        };
        logoPanel.setOpaque(false);
        logoPanel.setPreferredSize(new Dimension(50, 50));

        JPanel namePanel = new JPanel();
        namePanel.setOpaque(false);
        namePanel.setLayout(new BoxLayout(namePanel, BoxLayout.Y_AXIS));
        JLabel lbName = new JLabel("GreenLoop");
        lbName.setFont(F_BRAND); lbName.setForeground(C_TEXT);
        JLabel lbSub = new JLabel("Eco Supply Chain Hub");
        lbSub.setFont(F_BRAND2); lbSub.setForeground(C_TEXT_MUTED);
        namePanel.add(lbName); namePanel.add(Box.createVerticalStrut(3)); namePanel.add(lbSub);

        brand.add(logoPanel, BorderLayout.WEST);
        brand.add(namePanel, BorderLayout.CENTER);
        sidebar.add(brand, BorderLayout.NORTH);

        JPanel nav = new JPanel();
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        nav.setOpaque(false);
        nav.setBorder(new EmptyBorder(14, 12, 0, 12));

        String[][] defs = {
            {"dashboard", "⬡",  "Dashboard",    "Overview & KPIs"},
            {"products",  "◈",  "Products",     "Catalogue Manager"},
            {"clients",   "◎",  "Clients",      "Retail Directory"},
            {"agents",    "⛟", "Delivery Team", "Personnel & Fleet"},
            {"orders",    "◷",  "Logistics",    "Orders & Dispatch"}
        };
        navButtons = new NavButton[defs.length];
        for (int i = 0; i < defs.length; i++) {
            final String card = defs[i][0];
            final int idx = i;
            NavButton btn = new NavButton(defs[i][1], defs[i][2], defs[i][3]);
            navButtons[i] = btn;
            btn.addActionListener(e -> { setActive(navButtons[idx]); showCard(card); });
            nav.add(btn); nav.add(Box.createVerticalStrut(3));
        }
        sidebar.add(nav, BorderLayout.CENTER);

        JPanel footer = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(C_BORDER);
                g2.fillRect(18, 0, getWidth()-36, 1);
                g2.dispose();
            }
        };
        footer.setOpaque(false);
        footer.setBorder(new EmptyBorder(10, 18, 14, 18));
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        JLabel lbVer = new JLabel("v2.4.1  ·  Production");
        lbVer.setFont(new Font("Segoe UI", Font.PLAIN, 10)); lbVer.setForeground(new Color(50, 80, 60));
        footer.add(lbVer);
        sidebar.add(footer, BorderLayout.SOUTH);

        return sidebar;
    }

    private void setActive(NavButton active) {
        for (NavButton b : navButtons) b.setActive(b == active);
    }

    public class NavButton extends JButton {
        private final String icon, label, sub;
        private float hover = 0f;
        private boolean hovered = false, active = false;
        private final Timer hoverAnim;

        NavButton(String icon, String label, String sub) {
            this.icon = icon; this.label = label; this.sub = sub;
            setOpaque(false); setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setBorder(new EmptyBorder(9, 12, 9, 12)); setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            hoverAnim = new Timer(16, e -> {
                float target = hovered ? 1f : 0f;
                float step = 0.09f;
                if (Math.abs(hover - target) < step) { hover = target; ((Timer)e.getSource()).stop(); }
                else hover += (hover < target) ? step : -step;
                repaint();
            });
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hovered = true;  hoverAnim.start(); }
                @Override public void mouseExited(MouseEvent e)  { hovered = false; hoverAnim.start(); }
            });
        }
        void setActive(boolean a) { this.active = a; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,       RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,  RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            if (active) {
                g2.setPaint(new GradientPaint(0,0, new Color(68,218,116,55), getWidth(),0, new Color(68,218,116,8)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(C_ACCENT); g2.fillRoundRect(0, 7, 3, getHeight()-14, 3, 3);
            } else if (hover > 0f) {
                g2.setColor(new Color(255,255,255,(int)(hover*14))); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            }

            int ix = 12, midY = getHeight()/2;
            g2.setFont(new Font("Segoe UI Symbol", Font.BOLD, 15));
            Color ic = active ? C_ACCENT : lerpColor(C_TEXT_MUTED, C_TEXT_MID, hover);
            g2.setColor(ic);
            FontMetrics fim = g2.getFontMetrics();
            g2.drawString(icon, ix, midY + fim.getAscent()/2 - 4);
            int tx = ix + fim.stringWidth(icon) + 10;

            g2.setFont(F_NAV); g2.setColor(active ? C_TEXT : ic);
            g2.drawString(label, tx, midY - 1);

            g2.setFont(F_NAV_S);
            g2.setColor(active ? C_TEXT_MUTED : new Color(C_TEXT_MUTED.getRed(), C_TEXT_MUTED.getGreen(), C_TEXT_MUTED.getBlue(), (int)(95+hover*80)));
            g2.drawString(sub, tx, midY + 13);
            g2.dispose();
        }
    }

    private JPanel buildMain() {
        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);

        JPanel topBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0,0, new Color(11,19,15,230), 0,getHeight(), new Color(7,13,10,210)));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(C_BORDER); g2.fillRect(0,getHeight()-1,getWidth(),1);
                g2.dispose();
            }
        };
        topBar.setOpaque(false); topBar.setBorder(new EmptyBorder(13, 26, 13, 26));

        statusLabel = new JLabel("  ⬡  GreenLoop Operations Centre");
        statusLabel.setFont(F_TITLE); statusLabel.setForeground(C_ACCENT);
        topBar.add(statusLabel, BorderLayout.WEST);

        JPanel topRight = new JPanel();
        topRight.setOpaque(false); topRight.setLayout(new BoxLayout(topRight, BoxLayout.X_AXIS));

        JLabel clockLbl = new JLabel(); clockLbl.setFont(F_CLOCK); clockLbl.setForeground(C_TEXT_MUTED);
        refreshClock(clockLbl);
        new Timer(1000, e -> refreshClock(clockLbl)).start();

        JPanel pill = new JPanel() {
            int t = 0; { new Timer(40, e -> { t=(t+4)%360; repaint(); }).start(); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(68,218,116,22)); g2.fillRoundRect(0,0,getWidth(),getHeight(),getHeight(),getHeight());
                g2.setColor(new Color(68,218,116,55)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,getHeight(),getHeight());
                float pf = (float)(0.5+0.5*Math.sin(Math.toRadians(t)));
                int dotX = 7, dotY = getHeight()/2;
                g2.setColor(new Color(68,218,116,(int)(40+pf*60))); g2.fillOval(dotX-5,dotY-5,10,10);
                g2.setColor(C_ACCENT); g2.fillOval(dotX-3,dotY-3,6,6);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 10)); g2.setColor(C_ACCENT); g2.drawString("LIVE", 18, dotY+4);
                g2.dispose();
            }
        };
        pill.setOpaque(false); pill.setPreferredSize(new Dimension(58, 24)); pill.setMaximumSize(new Dimension(58, 24));

        topRight.add(clockLbl); topRight.add(Box.createHorizontalStrut(16)); topRight.add(pill);
        topBar.add(topRight, BorderLayout.EAST);
        main.add(topBar, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        contentArea = new JPanel(cardLayout); contentArea.setOpaque(false);

        contentArea.add(buildDashboardPanel(), "dashboard");
        contentArea.add(buildProductPanel(),   "products");
        contentArea.add(buildClientPanel(),    "clients");
        contentArea.add(buildAgentPanel(),     "agents");
        contentArea.add(buildOrderPanel(),     "orders");

        main.add(contentArea, BorderLayout.CENTER);
        return main;
    }

    private void refreshClock(JLabel lbl) {
        LocalDateTime now = LocalDateTime.now();
        lbl.setText(now.format(DateTimeFormatter.ofPattern("HH:mm:ss   yyyy-MM-dd")));
    }

    private JPanel buildDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 20));
        panel.setOpaque(false); panel.setBorder(new EmptyBorder(26, 28, 26, 28));

        JPanel statsRow = new JPanel(new GridLayout(1, 4, 16, 0));
        statsRow.setOpaque(false);
        String[] sIcons  = {"📦", "🏢", "📋", "⚠"};
        String[] sLabels = {"Total Products", "Active Clients", "Orders Tracked", "Low-Stock Alerts"};
        Color[]  sCols   = {C_ACCENT, C_SAPPHIRE, C_GOLD, C_DANGER};
        for (int i = 0; i < 4; i++) statsRow.add(buildStatCard(sIcons[i], sLabels[i], sCols[i], i));
        panel.add(statsRow, BorderLayout.NORTH);

        JPanel centerRow = new JPanel(new GridLayout(1, 2, 16, 0));
        centerRow.setOpaque(false);

        JPanel infoCard = buildGlassCard("🌿  Operations Overview");
        infoCard.setLayout(new BorderLayout());
        JPanel bullets = new JPanel(); bullets.setOpaque(false); bullets.setLayout(new BoxLayout(bullets, BoxLayout.Y_AXIS));
        String[] lines = {
            "◈  Live stock monitoring with dynamic reorder alerts",
            "◎  Comprehensive client registry and account management",
            "⛟  Fleet assignment and courier coordination portal",
            "◷  End-to-end dispatch and logistics tracking engine",
            "⬡  Automated audit reports and revenue analytics"
        };
        for (String line : lines) {
            JLabel bl = new JLabel(line); bl.setFont(F_INPUT); bl.setForeground(C_TEXT_MID);
            bl.setBorder(new EmptyBorder(4, 0, 4, 0)); bullets.add(bl);
        }
        infoCard.add(bullets, BorderLayout.CENTER); centerRow.add(infoCard);

        JPanel actCard = buildGlassCard("⚡  Quick Navigate");
        actCard.setLayout(new BoxLayout(actCard, BoxLayout.Y_AXIS));
        Object[][] qActions = {
            {"📦  Manage Products",   "products", 1},
            {"🏢  Manage Clients",    "clients",  2},
            {"⛟  Manage Agents",     "agents",   3},
            {"📋  Process Orders",    "orders",   4}
        };
        for (Object[] qa : qActions) {
            final String cKey = (String) qa[1]; final int nIdx = (int) qa[2];
            GlowBtn btn = new GlowBtn((String) qa[0], C_ACCENT_DIM, C_ACCENT);
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btn.addActionListener(e -> { setActive(navButtons[nIdx]); showCard(cKey); });
            actCard.add(btn); actCard.add(Box.createVerticalStrut(7));
        }
        centerRow.add(actCard); panel.add(centerRow, BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildStatCard(String icon, String lbl, Color col, int idx) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0,0, new Color(18,30,23), 0,getHeight(), new Color(13,22,17)));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setPaint(new GradientPaint(0,0, new Color(col.getRed(),col.getGreen(),col.getBlue(),190), getWidth()*3/4,0, new Color(col.getRed(),col.getGreen(),col.getBlue(),0)));
                g2.fillRoundRect(0,0,getWidth(),3,3,3);
                g2.setColor(new Color(col.getRed(),col.getGreen(),col.getBlue(),45)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.setColor(C_GLASS_SHEEN); g2.fillRoundRect(6,6,getWidth()-12,getHeight()/3,8,8);
                g2.dispose();
            }
        };
        card.setOpaque(false); card.setBorder(new EmptyBorder(16, 18, 16, 18));

        JLabel ico = new JLabel(icon); ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24)); card.add(ico, BorderLayout.NORTH);
        JLabel val = new JLabel("0"); val.setFont(F_STAT); val.setForeground(col); statLabels[idx] = val; card.add(val, BorderLayout.CENTER);
        JLabel txt = new JLabel(lbl); txt.setFont(F_SMALL); txt.setForeground(C_TEXT_MUTED); card.add(txt, BorderLayout.SOUTH);

        return card;
    }

    private void refreshStatCounters() {
        if (statLabels[0] == null) return;
        List<Product> products = pDAO.getAllProducts();
        long alerts = products.stream().filter(p -> p.getStockQty() <= p.getReorderLevel()).count();
        int[] targets = { products.size(), cDAO.getAllClients().size(), oDAO.getAllOrders().size(), (int)alerts };
        
        for (int i = 0; i < 4; i++) {
            final int fi = i, ft = targets[i];
            int from = 0;
            try { from = Integer.parseInt(statLabels[i].getText()); } catch (Exception ignored) {}
            if (from == ft) continue;
            final int delay = 30 * i;
            Timer t = new Timer(30, null); t.setInitialDelay(delay);
            t.addActionListener(e -> {
                int cur = 0; try { cur = Integer.parseInt(statLabels[fi].getText()); } catch (Exception ignored) {}
                if (cur != ft) statLabels[fi].setText(String.valueOf(cur + (cur < ft ? 1 : -1)));
                else ((Timer)e.getSource()).stop();
            });
            t.start();
        }
    }

    public JPanel buildGlassCard(String title) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0,0,C_CARD, 0,getHeight(),new Color(12,20,16))); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(C_BORDER); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.setColor(C_GLASS_SHEEN); g2.fillRoundRect(6,6,getWidth()-12,38,8,8);
                g2.dispose();
            }
        };
        card.setOpaque(false); card.setBorder(new EmptyBorder(18, 20, 18, 20));
        if (title != null) {
            JLabel lbl = new JLabel(title); lbl.setFont(F_TITLE2); lbl.setForeground(C_TEXT);
            lbl.setBorder(new EmptyBorder(0,0,12,0)); card.add(lbl, BorderLayout.NORTH);
        }
        return card;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PRODUCT MODULE (Requirement 1 & 3 Fulfillments)
    // ═══════════════════════════════════════════════════════════════════
    private JPanel buildProductPanel() {
        JPanel panel = panelWithPadding();
        productModel = tableModel("  ID", "  Name", "  Price (LKR)", "  Eco Rating", "  Stock", "  Reorder");
        productTable = new JTable(productModel); styleTable(productTable); refreshProductTable();
        
        productTable.getSelectionModel().addListSelectionListener(e -> {
            int r = productTable.getSelectedRow(); if (r < 0) return;
            txtProdId.setText(trim(productModel, r, 0)); txtProdName.setText(trim(productModel, r, 1));
            txtProdPrice.setText(productModel.getValueAt(r,2).toString()); txtProdEco.setText(trim(productModel, r, 3));
            txtProdQty.setText(productModel.getValueAt(r,4).toString()); txtProdReorder.setText(productModel.getValueAt(r,5).toString());
        });
        panel.add(styledScroll(productTable), BorderLayout.CENTER);

        JPanel form = buildGlassCard("◈  Product Catalogue");
        form.setPreferredSize(new Dimension(325, 0)); form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        txtProdId = sField(); addRow(form, "PRODUCT ID", txtProdId);
        txtProdName = sField(); addRow(form, "PRODUCT NAME", txtProdName);
        txtProdPrice = sField(); addRow(form, "PRICE (LKR)", txtProdPrice);
        txtProdEco = sField(); addRow(form, "ECO RATING", txtProdEco);
        txtProdQty = sField(); addRow(form, "STOCK QTY", txtProdQty);
        txtProdReorder = sField(); addRow(form, "REORDER THRESHOLD", txtProdReorder);
        form.add(Box.createVerticalStrut(12));

        GlowBtn btnSave = new GlowBtn("＋  Add / Save Product", C_ACCENT_DIM, C_ACCENT);
        GlowBtn btnStock = new GlowBtn("↑  Stock-In Entry", new Color(22,95,55), C_ACCENT_DIM);
        GlowBtn btnDelete = new GlowBtn("✕  Remove Product", C_DANGER_DIM, C_DANGER);
        sizeBtn(btnSave); sizeBtn(btnStock); sizeBtn(btnDelete);

        btnSave.addActionListener(e -> {
            try {
                Product p = new Product(txtProdId.getText(), txtProdName.getText(), Double.parseDouble(txtProdPrice.getText()), txtProdEco.getText(), Integer.parseInt(txtProdQty.getText()), Integer.parseInt(txtProdReorder.getText()));
                pDAO.saveProduct(p); refreshProductTable(); checkAlerts(); toast("Product saved!", C_ACCENT);
            } catch (Exception ex) { toast("Fill all fields correctly.", C_DANGER); }
        });
        
        // Fulfilling Requirement 3 (Stock-In from suppliers handled directly inside logic layer)
        btnStock.addActionListener(e -> {
            String s = styledInput("Enter incoming stock quantity to add:");
            if (s != null) {
                try {
                    String targetId = txtProdId.getText().trim();
                    int addedQty = Integer.parseInt(s.trim());
                    Product px = pDAO.getAllProducts().stream()
                        .filter(p -> p.getId().equalsIgnoreCase(targetId))
                        .findFirst().orElse(null);
                    
                    if (px != null) {
                        Product updated = new Product(px.getId(), px.getName(), px.getPrice(), px.getEcoRating(), px.getStockQty() + addedQty, px.getReorderLevel());
                        pDAO.saveProduct(updated);
                        refreshProductTable(); checkAlerts(); toast("Stock updated from supplier!", C_ACCENT);
                    } else {
                        toast("Select a product row first.", C_DANGER);
                    }
                } catch (Exception ex) { toast("Invalid quantity.", C_DANGER); }
            }
        });
        
        btnDelete.addActionListener(e -> {
            pDAO.deleteProduct(txtProdId.getText()); refreshProductTable(); checkAlerts(); toast("Product removed.", C_DANGER);
        });

        form.add(btnSave); form.add(vs(6)); form.add(btnStock); form.add(vs(6)); form.add(btnDelete);
        panel.add(form, BorderLayout.EAST);
        return panel;
    }

    private void refreshProductTable() {
        productModel.setRowCount(0);
        for (Product p : pDAO.getAllProducts())
            productModel.addRow(new Object[]{"  "+p.getId(),"  "+p.getName(),p.getPrice(),"  "+p.getEcoRating(),p.getStockQty(),p.getReorderLevel()});
    }

    // ═══════════════════════════════════════════════════════════════════
    //  CLIENT MODULE (Requirement 2 Fulfillment)
    // ═══════════════════════════════════════════════════════════════════
    private JPanel buildClientPanel() {
        JPanel panel = panelWithPadding();
        clientModel = tableModel("  Client ID", "  Name", "  Contact", "  Email");
        clientTable = new JTable(clientModel); styleTable(clientTable); refreshClientTable();
        clientTable.getSelectionModel().addListSelectionListener(e -> {
            int r = clientTable.getSelectedRow(); if (r < 0) return;
            txtClientId.setText(trim(clientModel,r,0)); txtClientName.setText(trim(clientModel,r,1));
            txtClientContact.setText(trim(clientModel,r,2)); txtClientEmail.setText(trim(clientModel,r,3));
        });
        panel.add(styledScroll(clientTable), BorderLayout.CENTER);

        JPanel form = buildGlassCard("◎  Client Registry");
        form.setPreferredSize(new Dimension(325, 0)); form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        txtClientId = sField(); addRow(form, "CLIENT ID", txtClientId);
        txtClientName = sField(); addRow(form, "COMPANY NAME", txtClientName);
        txtClientContact = sField(); addRow(form, "CONTACT NUMBER", txtClientContact);
        txtClientEmail = sField(); addRow(form, "EMAIL ADDRESS", txtClientEmail);
        form.add(Box.createVerticalStrut(12));

        GlowBtn btnSave = new GlowBtn("＋  Add / Update Client", C_ACCENT_DIM, C_ACCENT);
        GlowBtn btnDelete = new GlowBtn("✕  Remove Client Account", C_DANGER_DIM, C_DANGER);
        sizeBtn(btnSave); sizeBtn(btnDelete);

        btnSave.addActionListener(e -> {
            cDAO.saveClient(new Client(txtClientId.getText(), txtClientName.getText(), txtClientContact.getText(), txtClientEmail.getText()));
            refreshClientTable(); toast("Client saved!", C_ACCENT);
        });
        btnDelete.addActionListener(e -> {
            cDAO.deleteClient(txtClientId.getText()); refreshClientTable(); toast("Client removed.", C_DANGER);
        });

        form.add(btnSave); form.add(vs(6)); form.add(btnDelete);
        panel.add(form, BorderLayout.EAST);
        return panel;
    }

    private void refreshClientTable() {
        clientModel.setRowCount(0);
        for (Client c : cDAO.getAllClients())
            clientModel.addRow(new Object[]{"  "+c.getId(),"  "+c.getName(),"  "+c.getContact(),"  "+c.getEmail()});
    }

    // ═══════════════════════════════════════════════════════════════════
    //  DELIVERY AGENT MODULE (Requirement 4 Fulfillment)
    // ═══════════════════════════════════════════════════════════════════
    private JPanel buildAgentPanel() {
        JPanel panel = panelWithPadding();
        agentModel = tableModel("  Agent ID", "  Name", "  Vehicle", "  Email");
        agentTable = new JTable(agentModel); styleTable(agentTable); refreshAgentTable();
        agentTable.getSelectionModel().addListSelectionListener(e -> {
            int r = agentTable.getSelectedRow(); if (r < 0) return;
            txtAgentId.setText(trim(agentModel,r,0)); txtAgentName.setText(trim(agentModel,r,1));
            txtAgentVehicle.setText(trim(agentModel,r,2)); txtAgentEmail.setText(trim(agentModel,r,3));
        });
        panel.add(styledScroll(agentTable), BorderLayout.CENTER);

        JPanel form = buildGlassCard("⛟  Delivery Agents");
        form.setPreferredSize(new Dimension(325, 0)); form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        txtAgentId = sField(); addRow(form, "AGENT ID TOKEN", txtAgentId);
        txtAgentName = sField(); addRow(form, "COURIER NAME", txtAgentName);
        txtAgentVehicle = sField(); addRow(form, "VEHICLE REG.", txtAgentVehicle);
        txtAgentEmail = sField(); addRow(form, "AGENT EMAIL", txtAgentEmail);
        form.add(Box.createVerticalStrut(12));

        GlowBtn btnSave = new GlowBtn("＋  Register Agent", C_ACCENT_DIM, C_ACCENT);
        GlowBtn btnDelete = new GlowBtn("✕  Remove Personnel", C_DANGER_DIM, C_DANGER);
        sizeBtn(btnSave); sizeBtn(btnDelete);

        btnSave.addActionListener(e -> {
            aDAO.saveAgent(new DeliveryAgent(txtAgentId.getText(), txtAgentName.getText(), txtAgentVehicle.getText(), txtAgentEmail.getText()));
            refreshAgentTable(); toast("Agent registered!", C_ACCENT);
        });
        btnDelete.addActionListener(e -> {
            aDAO.deleteAgent(txtAgentId.getText()); refreshAgentTable(); toast("Agent removed.", C_DANGER);
        });

        form.add(btnSave); form.add(vs(6)); form.add(btnDelete);
        panel.add(form, BorderLayout.EAST);
        return panel;
    }

    private void refreshAgentTable() {
        agentModel.setRowCount(0);
        for (DeliveryAgent a : aDAO.getAllAgents())
            agentModel.addRow(new Object[]{"  "+a.getAgentId(),"  "+a.getName(),"  "+a.getVehicleDetails(),"  "+a.getEmail()});
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ORDERS & LOGISTICS (Requirement 5, 6, 7, 8, & 9 Fulfillments)
    // ═══════════════════════════════════════════════════════════════════
    private JPanel buildOrderPanel() {
        JPanel panel = panelWithPadding();
        orderModel = tableModel("  Order ID","  Client","  Product","  Qty","  Total","  Status","  Courier");
        orderTable = new JTable(orderModel); styleTable(orderTable);
        orderTable.getColumnModel().getColumn(5).setCellRenderer(new StatusRenderer());
        refreshOrderTable();
        panel.add(styledScroll(orderTable), BorderLayout.CENTER);

        JPanel form = buildGlassCard("◷  Logistics Entry");
        form.setPreferredSize(new Dimension(355, 0)); form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        comboClients = sCombo(); addRow(form, "TARGET CLIENT", comboClients);
        comboProducts = sCombo(); addRow(form, "PRODUCT SELECT", comboProducts);
        txtOrderQty = sField(); addRow(form, "QUANTITY", txtOrderQty);
        comboAgents = sCombo(); addRow(form, "ASSIGN COURIER", comboAgents);
        txtOrderId = sField(); addRow(form, "ORDER ID", txtOrderId);
        form.add(Box.createVerticalStrut(8));

        lblTotalCalc = new JLabel("Invoice Total:  LKR 0.00");
        lblTotalCalc.setFont(new Font("Segoe UI", Font.BOLD, 13)); lblTotalCalc.setForeground(C_ACCENT);
        
        JPanel totalPill = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(68,218,116,22)); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.setColor(new Color(68,218,116,55)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                g2.dispose();
            }
        };
        totalPill.setOpaque(false); totalPill.setBorder(new EmptyBorder(8,12,8,12));
        totalPill.setLayout(new BorderLayout()); totalPill.add(lblTotalCalc);
        totalPill.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42)); form.add(totalPill);
        form.add(Box.createVerticalStrut(12));

        txtOrderQty.addKeyListener(new KeyAdapter() {
            @Override public void keyReleased(KeyEvent e) {
                try {
                    String prodName = (String) comboProducts.getSelectedItem();
                    int qty = Integer.parseInt(txtOrderQty.getText().trim());
                    Product p = pDAO.getAllProducts().stream()
                        .filter(pr -> pr.getName().equalsIgnoreCase(prodName))
                        .findFirst().orElse(null);
                    lblTotalCalc.setText(p != null ? String.format("Invoice Total:  LKR %.2f", p.getPrice()*qty) : "Invoice Total:  LKR 0.00");
                } catch (Exception ignored) { lblTotalCalc.setText("Invoice Total:  LKR 0.00"); }
            }
        });

        GlowBtn btnDispatch = new GlowBtn("▶  Process & Dispatch", C_ACCENT_DIM, C_ACCENT);
        GlowBtn btnReport = new GlowBtn("⬡  Generate Audit Report", C_GOLD_DIM, C_GOLD);
        sizeBtn(btnDispatch); sizeBtn(btnReport); btnReport.setForeground(new Color(255,230,100));

        // Processing order dispatch, updating standard entities to satisfy Requirements 5, 6, 8, & 9
        btnDispatch.addActionListener(e -> {
            try {
                String prodName = (String) comboProducts.getSelectedItem();
                int qty = Integer.parseInt(txtOrderQty.getText().trim());
                Product px = pDAO.getAllProducts().stream()
                    .filter(pr -> pr.getName().equalsIgnoreCase(prodName))
                    .findFirst().orElse(null);
                
                if (px != null && px.getStockQty() >= qty) {
                    Product updatedProd = new Product(px.getId(), px.getName(), px.getPrice(), px.getEcoRating(), px.getStockQty() - qty, px.getReorderLevel());
                    pDAO.saveProduct(updatedProd);

                    double amt = px.getPrice() * qty;
                    Order ord = new Order(txtOrderId.getText().trim(), (String)comboClients.getSelectedItem(), prodName, qty, amt, "Dispatched", (String)comboAgents.getSelectedItem());
                    oDAO.saveOrder(ord);
                    
                    refreshOrderTable(); refreshProductTable(); checkAlerts();
                    fireEmails(ord); toast("Order dispatched successfully!", C_ACCENT);
                } else {
                    toast("Insufficient stock for this order!", C_DANGER);
                }
            } catch (Exception ex) { toast("Fill all fields correctly.", C_DANGER); }
        });
        
        // Fulfilling Requirement 7 (Generate Monthly Sales & Inventory Reports)
        btnReport.addActionListener(e -> auditDialog());

        form.add(btnDispatch); form.add(vs(8)); form.add(btnReport);
        panel.add(form, BorderLayout.EAST);
        return panel;
    }

    private void refreshOrderTable() {
        orderModel.setRowCount(0);
        for (Order o : oDAO.getAllOrders())
            orderModel.addRow(new Object[]{"  "+o.getOrderId(),"  "+o.getClientName(),"  "+o.getProductName(), o.getQuantity(), String.format("LKR %.2f",o.getTotalAmount()),o.getStatus(),"  "+o.getDeliveryAgentName()});
    }

    private static class StatusRenderer extends JLabel implements TableCellRenderer {
        StatusRenderer() { setOpaque(false); setHorizontalAlignment(CENTER); }
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            String s = v != null ? v.toString().trim() : ""; setText(s); setFont(new Font("Segoe UI", Font.BOLD, 11));
            if (s.equals("Dispatched")) { setForeground(new Color(68,218,116)); setBackground(new Color(68,218,116,30)); }
            else { setForeground(new Color(255,200,65)); setBackground(new Color(255,200,65,25)); }
            return this;
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground()); int ph = getHeight()-8, pw = Math.min(getPreferredSize().width+20, getWidth()-8);
            g2.fillRoundRect((getWidth()-pw)/2, 4, pw, ph, ph, ph); g2.dispose();
            super.paintComponent(g);
        }
    }

    // Fulfilling Requirement 7 (Complete system loop reads data from standard tables dynamically)
    private void auditDialog() {
        List<Order> orders = oDAO.getAllOrders(); List<Product> products = pDAO.getAllProducts();
        double rev = 0; for (Order o : orders) rev += o.getTotalAmount();
        StringBuilder sb = new StringBuilder();
        sb.append("╔══════════ GREENLOOP — MONTHLY AUDIT REPORT ══════════╗\n\n");
        sb.append(String.format("  Gross Revenue Invoiced :  LKR %,.2f\n", rev));
        sb.append(String.format("  Total Orders Processed :  %d\n",   orders.size()));
        sb.append(String.format("  Active Products        :  %d\n",   products.size()));
        sb.append(String.format("  Registered Clients     :  %d\n",   cDAO.getAllClients().size()));
        sb.append(String.format("  Active Couriers        :  %d\n\n", aDAO.getAllAgents().size()));
        sb.append("  ─────────────── INVENTORY ALERTS ───────────────\n");
        boolean any = false;
        for (Product p : products) {
            if (p.getStockQty() <= p.getReorderLevel()) {
                sb.append(String.format("  ⚠ %-22s [%s]  %d units  (threshold: %d)\n", p.getName(), p.getId(), p.getStockQty(), p.getReorderLevel()));
                any = true;
            }
        }
        if (!any) sb.append("  ✔ No low-stock alerts — inventory levels healthy.\n");
        sb.append("\n╚══════════════════════════════════════════════════════╝");
        showConsoleDialog("GreenLoop — Audit Report", sb.toString(), C_ACCENT);
    }

    // Fulfilling Requirements 8 & 9 (Simulates outbound notification triggers safely inside desktop layer)
    private void fireEmails(Order ord) {
        Client cl = cDAO.getAllClients().stream().filter(c -> c.getName().equals(ord.getClientName())).findFirst().orElse(null);
        DeliveryAgent ag = aDAO.getAllAgents().stream().filter(a -> a.getName().equals(ord.getDeliveryAgentName())).findFirst().orElse(null);
        String ce = cl != null ? cl.getEmail() : "client@retail-hub.com";
        String ae = ag != null ? ag.getEmail() : "courier@greenloop-logistics.com";
        String log =
            "╔══════════════════ SMTP GATEWAY LOG ══════════════════╗\n\n" +
            "  ✉  CLIENT NOTIFICATION SENT (Requirement 8)\n" +
            "     To      : " + ce + "\n" +
            "     Subject : Dispatch Confirmed — Ref #" + ord.getOrderId() + "\n\n" +
            "  ✉  COURIER NOTIFICATION SENT (Requirement 9)\n" +
            "     To      : " + ae + "\n" +
            "     Subject : Delivery Assignment — Order #" + ord.getOrderId() + "\n" +
            "╚══════════════════════════════════════════════════════╝";
        showConsoleDialog("Email Notification Engine — Outbox Status", log, new Color(68,218,116));
    }

    private void showConsoleDialog(String title, String text, Color fg) {
        JTextArea area = new JTextArea(text); area.setFont(F_MONO); area.setEditable(false);
        area.setBackground(new Color(9,16,12)); area.setForeground(fg); area.setBorder(new EmptyBorder(12,14,12,14));
        JScrollPane sp = new JScrollPane(area); sp.setPreferredSize(new Dimension(540, 340));
        sp.getViewport().setBackground(new Color(9,16,12)); sp.setBorder(new LineBorder(C_BORDER));
        JOptionPane.showMessageDialog(this, sp, title, JOptionPane.PLAIN_MESSAGE);
    }

    private void checkAlerts() {
        refreshStatCounters();
        for (Product p : pDAO.getAllProducts()) {
            if (p.getStockQty() <= p.getReorderLevel()) {
                statusLabel.setText("  ⚠  LOW STOCK: " + p.getName() + " is below reorder threshold");
                statusLabel.setForeground(C_DANGER); return;
            }
        }
        statusLabel.setText("  ⬡  GreenLoop Operations Centre — All Systems Nominal"); statusLabel.setForeground(C_ACCENT);
    }

    private void showCard(String key) {
        cardLayout.show(contentArea, key);
        if (key.equals("orders"))    refreshCombos();
        if (key.equals("dashboard")) refreshStatCounters();
        checkAlerts();
    }

    private void refreshCombos() {
        comboClients.removeAllItems(); comboProducts.removeAllItems(); comboAgents.removeAllItems();
        for (Client c : cDAO.getAllClients())  comboClients.addItem(c.getName());
        for (Product p : pDAO.getAllProducts()) comboProducts.addItem(p.getName());
        for (DeliveryAgent a : aDAO.getAllAgents())  comboAgents.addItem(a.getName());
    }

    public class GlowBtn extends JButton {
        private final Color base, glow; private float hp = 0f; private boolean hovering = false; private final Timer anim;
        private float rr = 0f, ra = 0f; private int rx, ry; private final Timer ripple;

        public GlowBtn(String text, Color base, Color glow) {
            super(text); this.base = base; this.glow = glow;
            setOpaque(false); setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setFont(F_LABEL); setForeground(Color.WHITE); setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(9, 18, 9, 18));

            anim = new Timer(16, e -> {
                float tgt = hovering ? 1f : 0f; float d = 0.08f;
                if (Math.abs(hp - tgt) < d) { hp = tgt; ((Timer)e.getSource()).stop(); }
                else hp += hp < tgt ? d : -d;
                repaint();
            });
            ripple = new Timer(16, e -> {
                rr += 9f; ra = Math.max(0f, ra - 0.045f); repaint();
                if (ra <= 0) ((Timer)e.getSource()).stop();
            });
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hovering = true;  anim.start(); }
                @Override public void mouseExited(MouseEvent e)  { hovering = false; anim.start(); }
                @Override public void mousePressed(MouseEvent e) { rx = e.getX(); ry = e.getY(); rr = 0; ra = 0.45f; ripple.start(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            Color bg = lerpColor(base, glow, hp);
            if (hp > 0f) {
                for (int i = 5; i >= 1; i--) {
                    g2.setColor(new Color(glow.getRed(), glow.getGreen(), glow.getBlue(), (int)(hp * i * 16)));
                    g2.fillRoundRect(-i*2, -i, getWidth()+i*4, getHeight()+i*2, 10, 10);
                }
            }
            g2.setPaint(new GradientPaint(0, 0, bg.brighter(), 0, getHeight(), bg)); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            if (ra > 0f) {
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, ra)); g2.setColor(Color.WHITE);
                g2.fillOval(rx-(int)rr, ry-(int)rr, (int)rr*2, (int)rr*2); g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            }
            g2.setFont(getFont()); g2.setColor(getForeground()); FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth()-fm.stringWidth(getText()))/2, (getHeight()+fm.getAscent()-fm.getDescent())/2);
            g2.dispose();
        }
    }

    private void styleTable(JTable t) {
        t.setRowHeight(36); t.setBackground(C_ROW_ALT); t.setForeground(C_TEXT); t.setGridColor(new Color(22, 38, 29));
        t.setSelectionBackground(new Color(68, 218, 116, 40)); t.setSelectionForeground(C_ACCENT); t.setFont(F_INPUT);
        t.setShowHorizontalLines(true); t.setShowVerticalLines(false);

        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                comp.setBackground(sel ? new Color(68,218,116,40) : (r%2==0 ? C_ROW_ALT : C_ROW_EVEN));
                comp.setForeground(sel ? C_ACCENT : C_TEXT); return comp;
            }
        });

        JTableHeader h = t.getTableHeader(); h.setReorderingAllowed(false); h.setBackground(new Color(8, 14, 11));
        h.setForeground(C_ACCENT); h.setFont(F_TINY); h.setPreferredSize(new Dimension(0, 38));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel l = new JLabel(v != null ? v.toString() : ""); l.setFont(F_TINY); l.setForeground(C_ACCENT);
                l.setOpaque(true); l.setBackground(new Color(8,14,11));
                l.setBorder(new CompoundBorder(new MatteBorder(0,0,1,0,C_BORDER), new EmptyBorder(5,8,5,8))); return l;
            }
        });
    }

    public JScrollPane styledScroll(JTable t) {
        JScrollPane sp = new JScrollPane(t); sp.setOpaque(false); sp.getViewport().setBackground(C_ROW_ALT);
        sp.setBorder(new LineBorder(C_BORDER, 1));
        sp.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { thumbColor = new Color(68,218,116,75); trackColor = C_ROW_ALT; }
            @Override protected JButton createDecreaseButton(int o) { return zeroBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return zeroBtn(); }
            JButton zeroBtn() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); return b; }
        });
        return sp;
    }

    public void toast(String msg, Color col) {
        JWindow w = new JWindow(this); w.setBackground(new Color(0,0,0,0));
        JPanel panel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(13,22,17,242)); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(new Color(col.getRed(),col.getGreen(),col.getBlue(),75)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                g2.dispose();
            }
        };
        panel.setOpaque(false); panel.setBorder(new EmptyBorder(10,18,10,18)); panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        JPanel dot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(col); g2.fillOval(0,(getHeight()-7)/2,7,7); g2.dispose();
            }
        };
        dot.setOpaque(false); dot.setPreferredSize(new Dimension(13,20));

        JLabel lbl = new JLabel(msg); lbl.setFont(new Font("Segoe UI", Font.BOLD, 12)); lbl.setForeground(C_TEXT);
        panel.add(dot); panel.add(Box.createHorizontalStrut(8)); panel.add(lbl); w.add(panel); w.pack();

        Point loc = getLocationOnScreen(); w.setLocation(loc.x + (getWidth()-w.getWidth())/2, loc.y + getHeight() - 88); w.setVisible(true);

        float[] alpha = {1.0f};
        Timer fadeTimer = new Timer(40, null);
        fadeTimer.addActionListener(e -> {
            alpha[0] -= 0.05f;
            if (alpha[0] <= 0f) { w.dispose(); ((Timer)e.getSource()).stop(); }
            else w.setOpacity(Math.max(0f, alpha[0]));
        });
        new Timer(1800, e -> { fadeTimer.start(); ((Timer)e.getSource()).stop(); }).start();
    }

    private String styledInput(String prompt) {
        JTextField f = sField(); f.setPreferredSize(new Dimension(220, 36));
        JPanel p = new JPanel(new BorderLayout(0, 8)); p.setBackground(new Color(15,25,19)); p.setBorder(new EmptyBorder(14,14,14,14));
        JLabel l = new JLabel(prompt); l.setForeground(C_TEXT); l.setFont(F_INPUT);
        p.add(l, BorderLayout.NORTH); p.add(f, BorderLayout.CENTER);
        int res = JOptionPane.showConfirmDialog(this, p, "Input Required", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        return res == JOptionPane.OK_OPTION ? f.getText() : null;
    }

    private static Color lerpColor(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
            (int)(a.getRed()   + (b.getRed()   - a.getRed())   * t),
            (int)(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
            (int)(a.getBlue()  + (b.getBlue()  - a.getBlue())  * t)
        );
    }

    public JTextField sField() {
        JTextField f = new JTextField() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(10, 17, 13)); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.setColor(hasFocus() ? new Color(68,218,116,90) : C_BORDER); g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 6, 6);
                g2.dispose(); super.paintComponent(g);
            }
        };
        f.setOpaque(false); f.setBackground(new Color(10,17,13)); f.setForeground(C_TEXT); f.setCaretColor(C_ACCENT); f.setFont(F_INPUT);
        f.setBorder(new EmptyBorder(7, 10, 7, 10)); f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        return f;
    }

    private JComboBox<String> sCombo() {
        JComboBox<String> cb = new JComboBox<>(); cb.setBackground(new Color(10,17,13)); cb.setForeground(C_TEXT); cb.setFont(F_INPUT);
        cb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        cb.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object val, int idx, boolean sel, boolean foc) {
                JLabel l = (JLabel) super.getListCellRendererComponent(list, val, idx, sel, foc);
                l.setBackground(sel ? new Color(28,55,38) : new Color(10,17,13)); l.setForeground(sel ? C_ACCENT : C_TEXT);
                l.setBorder(new EmptyBorder(5,10,5,10)); return l;
            }
        });
        return cb;
    }

    public void addRow(JPanel p, String label, JComponent comp) {
        JLabel l = new JLabel(label); l.setFont(F_TINY); l.setForeground(C_TEXT_MUTED);
        p.add(l); p.add(Box.createVerticalStrut(3)); p.add(comp); p.add(Box.createVerticalStrut(8));
    }

    public DefaultTableModel tableModel(String... cols) {
        return new DefaultTableModel(cols, 0) { @Override public boolean isCellEditable(int r, int c) { return false; } };
    }
    private JPanel panelWithPadding() {
        JPanel p = new JPanel(new BorderLayout(18, 0)); p.setOpaque(false); p.setBorder(new EmptyBorder(20, 26, 20, 26)); return p;
    }
    public String trim(DefaultTableModel m, int r, int c) { Object v = m.getValueAt(r, c); return v != null ? v.toString().trim() : ""; }
    private Component vs(int h) { return Box.createVerticalStrut(h); }
    public void sizeBtn(JButton b) { b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); b.setAlignmentX(Component.LEFT_ALIGNMENT); }
}